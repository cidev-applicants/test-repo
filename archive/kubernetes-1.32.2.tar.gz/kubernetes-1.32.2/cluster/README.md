# Cluster Configuration

##### Deprecation Notice: This directory has entered maintenance mode and will not be accepting new providers. Deployments in this directory will continue to be maintained and supported at their current level of support.

See the [Getting started](https://kubernetes.io/docs/setup/) guide for alternatives.