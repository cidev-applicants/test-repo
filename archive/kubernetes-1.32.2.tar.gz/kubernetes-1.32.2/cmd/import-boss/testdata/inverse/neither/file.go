package neither

var X = "neither"
