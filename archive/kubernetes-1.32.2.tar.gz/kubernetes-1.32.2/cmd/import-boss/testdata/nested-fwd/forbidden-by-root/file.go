package forbiddenbyroot

var X = "forbiddenbyroot"
